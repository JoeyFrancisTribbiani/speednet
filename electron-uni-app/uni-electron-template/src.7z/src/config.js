const CONFIGS = {
    dev: {
        APP_NAME: "uni-electron",
        APP_NAME_CN: "uni-electron",
        PORT: "27232",
        PRODUCTION: {
            HOST: "http://localhost",
            BASE_URL: "http://localhost:27232",
        },
        DEV: {
            HOST: "http://localhost",
            BASE_URL: "http://localhost:27232/api",
            FILE_URL: "http://localhost:27232",
        },
    },
}

const USE_CONFIG = CONFIGS.dev

console.log(USE_CONFIG)

export const SYS_CONFIG = {
    DevNo: "B5DD5-DF05E-6DE10-E8MVK-ZLCCG",
    SERVER_PORT: USE_CONFIG.PORT,
    APP_NAME: USE_CONFIG.APP_NAME,
    APP_NAME_CN: USE_CONFIG.APP_NAME_CN,
    FILE_URL:
        process.env.NODE_ENV === "production"
            ? USE_CONFIG.PRODUCTION.FILE_URL
            : USE_CONFIG.DEV.FILE_URL,
    BASE_URL:
        process.env.NODE_ENV === "production"
            ? USE_CONFIG.PRODUCTION.BASE_URL
            : USE_CONFIG.DEV.BASE_URL,
}

console.log(SYS_CONFIG)

// 全局配置，以后不用在main.js再导入了
export default {
    SYS_CONFIG,
}
