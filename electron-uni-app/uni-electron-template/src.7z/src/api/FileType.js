const FileType = {
    DOCUMENT: "DOCUMENT",
    VIDEO: "VIDEO",
    RADIO: "RADIO",
}
export { FileType }
