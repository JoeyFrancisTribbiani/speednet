<template>
    <text> description:{{ description }} author:{{ author }} </text>
</template>

<script>
export default {
    name: "myf",
    data() {
        return {
            description: "uni-app frame run in electron",
            author: "2317809130@qq.com",
        }
    },
}
</script>

<style scoped>
text {
    padding: 40px;
    display: inline-block;
    width: 100%;
    margin: 0 auto;
    text-align: center;
}
</style>
