<template>
    <view class="loginPage">
        <view class="box">
            <view class="test" />
            <image class="login-bg" src="/static/logo.png" />
            <image class="login-bg" src="~@/static/logo.png" />
        </view>
        <button @click="go">start</button>
        <myf />
    </view>
</template>

<script>
import { FileType } from "@/api/FileType"
import Myf from "@/pages/myf"

export default {
    name: "login",
    components: { Myf },
    data() {
        return {}
    },
    onLoad() {
        let i = FileType.DOCUMENT
        console.log(i)

        let user = {
            a: 0,
            b: undefined,
            n: null,
            c: { d: "isD", e: {} },
        }
        console.log(user.c?.d)
        //undefined
        console.log(user.c?.e?.q?.n)
        //undefined
        console.log(user.c?.d?.f)
        //undefined
        console.log(user.c?.d?.f?.l)
        //undefined
        console.log(user.f?.g)
        //error
        // console.log(user.f.g)

        //123
        console.log(user.b ?? "123")
        //0
        console.log(user.a ?? "123")
        //123
        console.log(user.a || "123")
        //123
        console.log(user.n ?? "123")
    },
    methods: {
        go() {
            uni.navigateTo({
                url: "/pages/myf",
            })
        },
    },
}
</script>

<style scoped>
.box {
    padding: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-bg {
    height: 100px;
    width: 100px;
}

.test {
    /*background-image: url('~@/static/pic-load-s.png');*/
    width: 100px;
    height: 100px;
    background-size: 100px 100px;
    background-repeat: no-repeat;
    /*background-image: url('@/static/pic-load-s.png');*/
    background-image: url("~@/static/logo.png");
    /*background-image: url('src/static/pic-load-s.png');*/
}
</style>
