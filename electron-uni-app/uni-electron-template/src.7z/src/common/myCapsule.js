export const getBtGroup = Object.freeze({
    DELETE: {
        id: 'DELETE',
        code: 3,
        name: '删除',
        style: {
            backgroundColor: '#ED4040',
        },
    },
})
