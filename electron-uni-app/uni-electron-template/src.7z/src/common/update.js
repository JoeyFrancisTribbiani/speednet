/**
 * 更新检测
 * @param forceUpdate 更新失败的提示
 */
function checkAndUpdate(forceUpdate) {
    // #ifdef MP-WEIXIN
    let e = wx.getUpdateManager()
    console.log('check update')
    e.onCheckForUpdate(function (t) {
        t.hasUpdate &&
            (e.onUpdateReady(function () {
                console.log('update ready')
                wx.showModal({
                    title: '更新提示',
                    content: '新版本已经准备好，是否重启应用？',
                    success: function (t) {
                        console.log('update success')
                        t.confirm && e.applyUpdate()
                    },
                })
            }),
            e.onUpdateFailed(function () {
                console.log('update fail')
                wx.showModal({
                    title: '已经有新版本咯~',
                    content: '请您删除当前小程序，到微信 “发现-小程序” 页，重新搜索打开呦~',
                })
            }))
    })
    // #endif
}

export { checkAndUpdate }
