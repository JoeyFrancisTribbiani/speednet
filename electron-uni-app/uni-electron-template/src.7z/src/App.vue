<script>
import { mapMutations } from 'vuex'
import { checkAndUpdate } from '@/common/update'

export default {
    onLaunch: function () {
        console.log('App Launch')

        // #ifdef MP
        if ('develop,trial'.indexOf(wx.getAccountInfoSync().miniProgram.envVersion) > -1)
            wx.setEnableDebug({
                enableDebug: true,
            })
        // #endif

        // #ifdef APP-PLUS
        // App平台检测升级，服务端代码是通过uniCloud的云函数实现的，详情可参考：https://ext.dcloud.net.cn/plugin?id=2226
        if (plus.runtime.appid !== 'HBuilder') {
            // 真机运行不需要检查更新，真机运行时appid固定为'HBuilder'，这是调试基座的appid
            uni.request({
                url: 'https://7a3e3fa9-7820-41d0-be80-11927ac2026c.bspapp.com/http/update', //检查更新的服务器地址
                data: {
                    appid: plus.runtime.appid,
                    version: plus.runtime.version,
                    imei: plus.device.imei,
                },
                success: res => {
                    if (res.statusCode == 200 && res.data.isUpdate) {
                        // 提醒用户更新
                        uni.showModal({
                            title: '更新提示',
                            content: res.data.note ? res.data.note : '是否选择更新',
                            success: ee => {
                                if (ee.confirm) {
                                    plus.runtime.openURL(res.data.url)
                                }
                            },
                        })
                    }
                },
            })
        }

        // 一键登录预登陆，可以显著提高登录速度
        uni.preLogin({
            provider: 'univerify',
            success: res => {
                // 成功
                this.setUniverifyErrorMsg()
                console.log('preLogin success: ', res)
            },
            fail: res => {
                this.setUniverifyLogin(false)
                this.setUniverifyErrorMsg(res.errMsg)
                // 失败
                console.log('preLogin fail res: ', res)
            },
        })
        // #endif
        checkAndUpdate(true)
    },
    onShow: function () {
        console.log('App Show')
    },
    onHide: function () {
        console.log('App Hide')
    },
    globalData: {
        test: '',
    },
    methods: {
        ...mapMutations(['setUniverifyErrorMsg', 'setUniverifyLogin']),
    },
}
</script>

<style>
/*@font-face { font-family: test; font-weight: normal; font-style: normal; src: url("~@/static/test.ttf") format("truetype"); }*/
/* #ifndef APP-PLUS-NVUE */
/* uni.css - 通用组件、模板样式库，可以当作一套ui库应用 */
@import './common/uni.css';

/*view{*/
/*    font-family: "PingFang SC", "Helvetica Neue", Helvetica, "Nimbus Sans L", Arial, "Liberation Sans", "Hiragino Sans GB", "Source Han Sans CN Normal", "Microsoft YaHei",sans-serif;*/
/*}*/
/* H5 兼容 pc 所需 */
/* #ifdef H5 */
@media screen and (min-width: 768px) {
    body {
        overflow-y: scroll;
    }
}

/* 顶栏通栏样式 */
/* .uni-top-window {
    left: 0;
    right: 0;
} */

uni-page-body {
    background-color: #f5f5f5 !important;
    min-height: 100% !important;
    height: auto !important;
}

.uni-top-window uni-tabbar .uni-tabbar {
    background-color: #fff !important;
}

.uni-app--showleftwindow .hideOnPc {
    display: none !important;
}

/* #endif */

/* 以下样式用于 hello uni-app 演示所需 */
page {
    background-color: #f6f6f6;
    height: 100%;
    font-size: 28rpx;
    line-height: 1.8;
}

.fix-pc-padding {
    padding: 0 50px;
}

.uni-header-logo {
    padding: 30rpx;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-top: 10rpx;
}

.uni-header-image {
    width: 100px;
    height: 100px;
}

.uni-hello-text {
    color: #7a7e83;
}

.uni-hello-addfile {
    text-align: center;
    line-height: 300rpx;
    background: #fff;
    padding: 50rpx;
    margin-top: 10px;
    font-size: 38rpx;
    color: #808080;
}

/* #endif*/

.bar_line_before {
    position: relative;
}

.bar_line_before:before {
    position: absolute;
    content: '';
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    height: 6rpx;
    width: 66rpx;
    background: #da3947;
    border-radius: 6rpx;
    z-index: 10;
}

.ellipsis-2 {
    /* #ifndef APP-NVUE */
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    /* #endif */
    /* #ifdef APP-NVUE */
    lines: 2;
    /* #endif */
}

/* ============== tab bar start ============*/
.m-navList {
    width: 750rpx;

    position: sticky;
    top: var(--window-top);

    z-index: 40;
    background: #fff;
}

.m-navList :after {
    position: absolute;
    content: '';
    bottom: 0;
    height: 2rpx;
    width: 100%;
    background: #ececec;
    z-index: 2;
}

.m-navItem {
    font-size: 32rpx;
    min-width: 100rpx;
    color: #000;
    text-align: center;
    padding: 0px 13px;
    line-height: 120%;
    padding-bottom: 13px;
    padding-top: 15px;
}

.m-tab-container {
    position: unset;

    /*width: 90.5%;*/
    width: 750rpx;
    display: flex;
    align-items: center;
    align-content: center;
    white-space: nowrap;
    overflow-x: auto;
    background: #ffffff;
}

/* ============== tab bar end ============*/

/*.uni-scroll-view{*/
/*    overflow: hidden!important;*/
/*}*/

/*修改滚动条样式*/
uni-view::-webkit-scrollbar {
    width: 10px;
    height: 0px;
    /**/
}
.m-navList::-webkit-scrollbar,
.m-tab-container::-webkit-scrollbar {
    width: 10px;
    height: 0px;
}

/*uni-rich-text img,rich-text img,.person-desc img{*/
/*    max-width: 690rpx!important;*/
/*}*/

image {
    will-change: transform;
}

.uni-scroll-view {
    position: unset;
}

/*.radio-look uni-checkbox .uni-checkbox-input {*/
/*    background-color: #fff;*/
/*    border-radius: 100%;*/
/*}*/

/*.radio-look uni-checkbox .uni-checkbox-input.uni-checkbox-input-checked:before {*/
/*    font-size: 18px;*/
/*    color: #fff;*/
/*}*/

/*.radio-look uni-checkbox .uni-checkbox-input.uni-checkbox-input-checked {*/
/*    background: #007aff;*/
/*}*/

.ques-wrong-choice .uni-radio-input.uni-radio-input-checked:before {
    font: normal normal normal 25px uniicons;
    content: '\E460';
}

.uni-media-list {
    align-items: center;
}
</style>
